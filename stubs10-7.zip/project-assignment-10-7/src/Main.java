/**
 * @author Yasser Abdelaal, Kate Bagshaw, Evan DeAngelis, David Olaoye, Jessica Schwartz
 */

public class Main{
	
	/**
	 * Creates & instantiates new controller,
	 * calls Controller's start method to begin the game. 
	 */
	public static void main(String[] args) {}
}